export const environment = {
    jwtPrivateKey: '159357'
}