import { DataSource, DataSourceOptions } from 'typeorm'

const Config: DataSourceOptions = {
    type: "mysql",
    host: "localhost",
    port: 3306,
    username: "oficinagaragem",
    password: "0f1c1n@_G@r4G3m",
    database: "oficina_garagem",

    synchronize: false,
    logging: ["error"],
    entities: [
        __dirname + "/../modelos/*{.js,.ts}",
        __dirname + "/../modelos/*/*{.js,.ts}",
        __dirname + "/../modelos/*/*/*{.js,.ts}"
    ],
    subscribers: [],
    migrations: [__dirname + "/../migrations/*{.js,.ts}"],
}

export const AppDataSource = new DataSource(Config)