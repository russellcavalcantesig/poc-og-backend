export class DebugResponse {
    response: any;
    constructor(response: any) {
        this.response = response
    }
}